/**
 * Represents a customer in the cafe.
 */
public class Customer extends Person {
    private int customerID;

    public Customer(int customerID, String name, String phone, String email, String address) {
        super(name, phone, email, address);
        this.customerID = customerID;
    }

    public void makePayment(Order order) {
        System.out.println("Processing payment for order ID: " + order.getOrderID());
    }

    public int getCustomerID() {
        return customerID;
    }
}
