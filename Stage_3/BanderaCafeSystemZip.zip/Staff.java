public class Staff extends Person {
    private int staffID;
    private String role;
    private Schedule schedule;
    private double hoursWorked;
    private double hourlyRate = 15.00;

    public Staff(int staffID, String name, String role, String phone, String email, Schedule schedule) {
        super(name, phone, email, "");  // Set default address as "N/A"
        this.staffID = staffID;
        this.role = role;
        this.schedule = schedule;
    }

    public void addHours(double hours) {
        this.hoursWorked += hours;
    }

    public double calculatePaycheck() {
        return hoursWorked * hourlyRate;
    }

    public int getStaffID() {
        return staffID;
    }

    public String getRole() {
        return role;
    }
}

