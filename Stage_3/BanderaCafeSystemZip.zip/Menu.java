import java.util.ArrayList;
import java.util.List;

/**
 * Represents the cafe's menu with available items.
 */
public class Menu {
    private List<Item> items;

    public Menu() {
        this.items = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public List<Item> getItems() {
        return items;
    }

    public void showMenu() {
        System.out.println("\n--- Cafe Menu ---");
        for (Item item : items) {
            System.out.println(item.getItemID() + ". " + item.getName() + " - $" + item.getPrice());
        }
    }
}
