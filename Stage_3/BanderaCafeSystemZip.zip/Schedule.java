/**
 * Represents a schedule for a staff member at the cafe.
 */
public class Schedule {
    private int staffID;
    private String dayOfWeek;
    private String shiftType;

    public Schedule(int staffID, String dayOfWeek, String shiftType) {
        this.staffID = staffID;
        this.dayOfWeek = dayOfWeek;
        this.shiftType = shiftType;
    }

    public int getStaffID() {
        return staffID;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public String getShiftType() {
        return shiftType;
    }

    public void setShiftType(String shiftType) {
        this.shiftType = shiftType;
    }
}
