/**
 * Represents a table in the cafe with occupancy and reservation status.
 */
public class Table {
    private int tableID;
    private int capacity;
    private boolean isOccupied;
    private boolean isReserved;
    private Customer assignedCustomer;

    public Table(int tableID, int capacity) {
        this.tableID = tableID;
        this.capacity = capacity;
        this.isOccupied = false;
        this.isReserved = false;
    }

    public int getTableID() {
        return tableID;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean checkAvailability() {
        return !isOccupied && !isReserved;
    }

    public void occupyTable(Customer customer) {
        if (checkAvailability()) {
            isOccupied = true;
            assignedCustomer = customer;
        } else {
            System.out.println("Table is not available to occupy.");
        }
    }

    public void releaseTable() {
        isOccupied = false;
        assignedCustomer = null;
    }

    public void reserveTable(Customer customer) {
        if (!isReserved) {
            isReserved = true;
            assignedCustomer = customer;
        } else {
            System.out.println("Table is already reserved.");
        }
    }

    public void unreserveTable() {
        isReserved = false;
        assignedCustomer = null;
    }

    public String getStatus() {
        if (isOccupied) return "Occupied";
        if (isReserved) return "Reserved";
        return "Available";
    }
}
