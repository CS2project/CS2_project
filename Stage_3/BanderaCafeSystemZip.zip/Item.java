/**
 * Represents an item on the menu at the cafe.
 */
public class Item {
    private int itemID;
    private String name;
    private double price;
    private String category;
    private boolean isAvailable;

    public Item(int itemID, String name, double price, String category, boolean isAvailable) {
        this.itemID = itemID;
        this.name = name;
        this.price = price;
        this.category = category;
        this.isAvailable = isAvailable;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getItemID() {
        return itemID;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailability(boolean available) {
        isAvailable = available;
    }
}
