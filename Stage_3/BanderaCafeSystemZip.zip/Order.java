import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderID;
    private List<Item> items;  // List of items in the order
    private int tableID;

    public Order(int orderID, int tableID) {
        this.orderID = orderID;
        this.tableID = tableID;
        this.items = new ArrayList<>();  // Initialize items list
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public void cancelOrder() {
        items.clear();
    }

    public void displayOrderItems() {
        System.out.println("Order ID: " + orderID);
        for (Item item : items) {
            System.out.println(item.getName() + " - $" + item.getPrice());
        }
    }

    public int getOrderID() {
        return orderID;
    }

    // New method to retrieve the list of items in the order
    public List<Item> getItems() {
        return items;
    }
}
